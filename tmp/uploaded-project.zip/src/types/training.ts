export type MuscleGroup =
  | "BICIPITI" | "TRICIPITI" | "DELTOIDI" | "DORSO" | "PETTO"
  | "QUADRICIPITI" | "FEMORALI" | "GLUTEI" | "POLPACCI" | "CORE";

export type ExerciseRole =
  | "ATTIVAZIONE" | "FONDAMENTALE" | "COMPLEMENTARE"
  | "ANALITICO" | "FORZA" | "BURNOUT" | "CARDIO";

export interface Exercise {
  id: string;
  day: number; // 1..7
  muscleGroup: MuscleGroup;
  role: ExerciseRole;
  name: string;
  sets: number;
  reps: string;   // es. "8–10" oppure "5x5"
  rir?: number;   // es. 1-3
  notes?: string;
}
