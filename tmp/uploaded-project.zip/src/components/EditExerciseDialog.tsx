import * as React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import type { Exercise } from "@/types/training";

type Props = {
  open: boolean;
  initial: Exercise | null;
  onClose: () => void;
  onSave: (updated: Exercise) => void;
};

export function EditExerciseDialog({ open, initial, onClose, onSave }: Props) {
  const [form, setForm] = React.useState<Exercise | null>(initial);

  React.useEffect(() => setForm(initial), [initial]);

  if (!form) return null;

  const set = <K extends keyof Exercise>(k: K, v: Exercise[K]) =>
    setForm(prev => (prev ? { ...prev, [k]: v } : prev));

  return (
    <Dialog open={open} onOpenChange={(o) => (!o ? onClose() : null)}>
      <DialogContent className="sm:max-w-[520px] bg-neutral-900 border border-yellow-500/30 text-yellow-50">
        <DialogHeader>
          <DialogTitle className="text-yellow-300">Modifica Esercizio</DialogTitle>
        </DialogHeader>

        <div className="grid gap-3 py-2">
          <div className="grid gap-1.5">
            <Label>Nome</Label>
            <Input value={form.name} onChange={e => set("name", e.target.value)} />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label>Serie</Label>
              <Input type="number" min={1} value={form.sets}
                     onChange={e => set("sets", Number(e.target.value) || 0)} />
            </div>
            <div className="grid gap-1.5">
              <Label>Reps</Label>
              <Input placeholder="8–10 oppure 5x5" value={form.reps}
                     onChange={e => set("reps", e.target.value)} />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label>RIR (opz.)</Label>
              <Input type="number" value={form.rir ?? ""} onChange={e => {
                const v = e.target.value;
                set("rir", v === "" ? undefined : Number(v));
              }} />
            </div>
            <div className="grid gap-1.5">
              <Label>Day</Label>
              <Input type="number" min={1} max={7} value={form.day}
                     onChange={e => set("day", Number(e.target.value) || 1)} />
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label>Note</Label>
            <Textarea rows={3} value={form.notes ?? ""} onChange={e => set("notes", e.target.value)} />
          </div>
        </div>

        <DialogFooter>
          <Button variant="secondary" onClick={onClose}>Annulla</Button>
          <Button className="bg-yellow-500 hover:bg-yellow-400 text-black font-semibold"
                  onClick={() => onSave(form!)}>
            Salva
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
