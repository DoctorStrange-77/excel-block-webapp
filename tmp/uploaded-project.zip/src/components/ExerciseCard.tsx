import { Pencil, Trash2 } from "lucide-react";
import { cn } from "@/lib/utils";
import type { Exercise } from "@/types/training";

type Props = {
  exercise: Exercise;
  onEdit: (ex: Exercise) => void;
  onDelete: (id: string) => void;
  className?: string;
};

export default function ExerciseCard({ exercise, onEdit, onDelete, className }: Props) {
  return (
    <div
      className={cn(
        "relative rounded-lg border border-yellow-500/40 bg-yellow-500/20 p-3 text-yellow-100",
        "shadow-sm hover:shadow-md transition-shadow",
        className
      )}
    >
      <div className="flex items-center justify-between">
        <div className="text-[10px] tracking-widest font-semibold text-yellow-300">
          {exercise.role}
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => onEdit(exercise)}
            className="inline-flex items-center rounded-md border border-yellow-400/60 px-2 py-1 text-[11px] hover:bg-yellow-400/10"
            title="Modifica esercizio"
          >
            <Pencil className="mr-1 h-3 w-3" />
            Modifica
          </button>

          <button
            onClick={() => onDelete(exercise.id)}
            className="inline-flex items-center rounded-md border border-red-400/60 px-2 py-1 text-[11px] text-red-300 hover:bg-red-400/10"
            title="Elimina esercizio"
          >
            <Trash2 className="mr-1 h-3 w-3" />
            Elimina
          </button>
        </div>
      </div>

      <div className="mt-2 text-sm">
        <div className="font-semibold text-yellow-200">{exercise.muscleGroup}</div>
        <div className="text-[13px] text-yellow-100/90">{exercise.name}</div>
        <div className="mt-1 text-[12px] text-yellow-300/90">
          Serie: <b>{exercise.sets}</b> · Reps: <b>{exercise.reps}</b>
          {typeof exercise.rir === "number" && <> · RIR: <b>{exercise.rir}</b></>}
        </div>
        {exercise.notes && (
          <div className="mt-1 text-[12px] text-yellow-200/80 italic">{exercise.notes}</div>
        )}
      </div>
    </div>
  );
}
